import { getRun } from "@/lib/oracle-data"
import { OracleProvider } from "@/components/oracle/oracle-provider"

// Re-read public/run.json on every request so swapping the file needs no rebuild.
export const dynamic = "force-dynamic"
import { Sidebar } from "@/components/oracle/sidebar"
import { OracleHeader } from "@/components/oracle/oracle-header"
import { MainView } from "@/components/oracle/main-view"
import { StatusBar } from "@/components/oracle/status-bar"

export default async function Page() {
  const run = await getRun()

  return (
    <OracleProvider run={run}>
      <div className="relative min-h-screen overflow-hidden bg-background">
        {/* ambient hero glow + vignette */}
        <div
          className="pointer-events-none fixed inset-0 bg-cover bg-center opacity-[0.06]"
          style={{ backgroundImage: "url(/images/curze-hero.jpeg)" }}
          aria-hidden
        />
        <div
          className="pointer-events-none fixed inset-0"
          style={{
            background:
              "radial-gradient(120% 80% at 50% -10%, oklch(0.3 0.05 25 / 16%), transparent 60%)",
          }}
          aria-hidden
        />

        <div className="relative flex">
          <Sidebar />
          <main className="flex-1 space-y-4 p-4">
            <OracleHeader />
            <MainView />
            <StatusBar />
          </main>
        </div>
      </div>
    </OracleProvider>
  )
}
