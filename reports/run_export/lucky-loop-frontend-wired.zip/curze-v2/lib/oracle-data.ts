// ============================================================================
// CURZE ORACLE — data layer
// Single async getRun() returns the full run (steps / predictions / verdict /
// papers / traces / diffs / findings). Defaults to embedded data so the UI works
// offline; swap the body for a `fetch("/api/run")` later without touching the UI.
// ============================================================================

export const ORACLE = {
  model: "Qwen-AgentWorld-35B-A3B",
  mode: "PREDICT",
  status: "AWAKE",
  context: "128K",
  repo: "github.com/enyolanev-bit/lucky-loop",
  currentStateId: "s_7C1A92F",
  dataset: "breast_cancer",
  motto: "NO MERCY. ONLY EVIDENCE.",
  railFooter: "VERIFY BEFORE CLAIM",
} as const

export type Prediction = {
  rank: number
  id: string
  config: string
  accLow: number
  accHigh: number
  probability: number
  tag?: { label: string; tone: "anomaly" | "low" | "top" }
}

export type StepStatus = "QUEUED" | "RUNNING" | "DONE"

export type PipelineStep = {
  key: string
  title: string
  detail: string
  // line spoken aloud when this step runs (Web Speech API)
  speak: string
  // log lines streamed when this step runs
  log: LogLine[]
}

export type LogLine = {
  tag: string
  text: string
  tone?: "info" | "ok" | "miss" | "alert"
}

export type Verdict = {
  state: "BLOCKED" | "CONFIRMED"
  title: string
  titleLab: string
  reason: string
  reasonLab: string
  effect: number
  noise: number
}

export type Paper = {
  title: string
  authors: string
  ref: string
  url: string
}

export type Trace = { time: string; source: string; event: string }

export type Diff = {
  step: string
  before: number
  after: number
  delta: number
}

export type Finding = { stat: string; label: string }

export type Run = {
  currentState: { id: string; dataset: string; context: string }
  predictions: Prediction[]
  pipeline: PipelineStep[]
  verdict: Verdict
  papers: Paper[]
  traces: Trace[]
  diffs: Diff[]
  findings: Finding[]
}

// ---------------------------------------------------------------------------

const RUN: Run = {
  currentState: {
    id: "s_7C1A92F",
    dataset: "breast_cancer",
    context: "Sources ingested · 4 papers · 87 claims extracted",
  },
  predictions: [
    {
      rank: 1,
      id: "s_7C1AA3D1",
      config: "logistic_regression + scale",
      accLow: 0.95,
      accHigh: 0.97,
      probability: 0.62,
      tag: { label: "TOP OUTCOME", tone: "top" },
    },
    {
      rank: 2,
      id: "s_7C1AB7E9",
      config: "random_forest",
      accLow: 0.93,
      accHigh: 0.96,
      probability: 0.24,
      tag: { label: "ANOMALY", tone: "anomaly" },
    },
    {
      rank: 3,
      id: "s_7C1AC4F6",
      config: "svc (rbf)",
      accLow: 0.9,
      accHigh: 0.94,
      probability: 0.14,
      tag: { label: "LOW CONFIDENCE", tone: "low" },
    },
  ],
  pipeline: [
    {
      key: "scout",
      title: "SCOUT arXiv",
      detail: "Crawl recent papers",
      speak: "Scouting arXiv for relevant world-model and agent papers.",
      log: [
        { tag: "SCOUT", text: "querying arXiv cs.LG + cs.AI ..." },
        { tag: "SCOUT", text: "142 candidates → 4 relevant" },
      ],
    },
    {
      key: "fetch",
      title: "FETCH PAPERS",
      detail: "Download PDFs",
      speak: "Fetching candidate papers.",
      log: [
        { tag: "FETCH", text: "arXiv:2606.24597 Qwen-AgentWorld" },
        { tag: "FETCH", text: "arXiv:2408.06292 The AI Scientist", tone: "ok" },
      ],
    },
    {
      key: "extract",
      title: "EXTRACT CLAIMS",
      detail: "Parse method + metrics",
      speak: "Extracting structured claims and baselines.",
      log: [
        { tag: "EXTRACT", text: "87 claims · 31 with metrics" },
        { tag: "EXTRACT", text: "baseline acc ~0.95 on breast_cancer" },
      ],
    },
    {
      key: "predict",
      title: "PREDICT",
      detail: "Qwen-AgentWorld · before compute",
      speak:
        "Oracle predicts logistic regression with scaling reaches accuracy zero point nine five to zero point nine seven, before any compute.",
      log: [
        { tag: "PREDICT", text: "logreg+scale → acc 0.95–0.97 · p=0.62" },
        { tag: "PREDICT", text: "random_forest → 0.93–0.96 · p=0.24" },
      ],
    },
    {
      key: "run",
      title: "RUN EXPERIMENT",
      detail: "real sklearn · 5-fold CV",
      speak:
        "Running the real experiment. Logistic regression scaled scores zero point nine seven nine. Prophecy fulfilled.",
      log: [
        { tag: "RUN", text: "sklearn fit · StandardScaler + LogReg" },
        { tag: "RUN", text: "logreg 0.951 → scaled 0.979 (+0.028)", tone: "ok" },
        { tag: "RUN", text: "tune C=1.0 → 0.986 (+0.007)", tone: "ok" },
      ],
    },
    {
      key: "cross",
      title: "CROSS-CHECK",
      detail: "verifier · effect vs noise",
      speak:
        "Verifier compares effect to seed noise. Effect zero point zero two one is below noise zero point zero two eight.",
      log: [
        { tag: "CROSS", text: "effect=0.021 vs seed_noise=0.028" },
        { tag: "CROSS", text: "single split — not significant", tone: "miss" },
      ],
    },
    {
      key: "report",
      title: "REPORT",
      detail: "verdict + provenance",
      speak:
        "Verdict: claim blocked. The effect lies within noise. A single split is an omen, not a truth.",
      log: [
        { tag: "VERDICT", text: "CLAIM BLOCKED — effect < seed noise", tone: "alert" },
        { tag: "REPORT", text: "provenance written · 5 traces CLEAN", tone: "ok" },
      ],
    },
  ],
  verdict: {
    state: "BLOCKED",
    title: "CLAIM BLOCKED",
    titleLab: "NO SIGNIFICANT DIFFERENCE",
    reason:
      "Best mean at C=0.1 — but a single split is an omen, not a truth. No robust best-model claim is allowed.",
    reasonLab:
      "Best mean accuracy at C=0.1, but the observed effect (0.021) is smaller than the across-seed std (0.028). On a single split this is within noise — no best-model claim is supported.",
    effect: 0.021,
    noise: 0.028,
  },
  papers: [
    {
      title: "Qwen-AgentWorld: Language World Models for General Agents",
      authors: "Qwen Team · 2026",
      ref: "arXiv:2606.24597",
      url: "https://arxiv.org/abs/2606.24597",
    },
    {
      title: "The AI Scientist: Fully Automated Open-Ended Scientific Discovery",
      authors: "Lu, Chris et al. · 2024",
      ref: "arXiv:2408.06292",
      url: "https://arxiv.org/abs/2408.06292",
    },
    {
      title: "Agent Laboratory: Using LLM Agents as Research Assistants",
      authors: "Schmidgall, Samuel et al. · 2025",
      ref: "arXiv:2501.04227",
      url: "https://arxiv.org/abs/2501.04227",
    },
    {
      title: "MLE-bench: Evaluating ML Agents on Machine Learning Engineering",
      authors: "Chan, Jun Shern et al. · 2024",
      ref: "arXiv:2410.07095",
      url: "https://arxiv.org/abs/2410.07095",
    },
  ],
  traces: [
    { time: "13:47:18", source: "arXiv:2606.24597", event: "Extracted 31 claims" },
    { time: "13:47:16", source: "arXiv:2408.06292", event: "Extracted 24 claims" },
    { time: "13:47:14", source: "arXiv:2501.04227", event: "Extracted 19 claims" },
    { time: "13:47:12", source: "arXiv:2410.07095", event: "Extracted 13 claims" },
    { time: "13:47:10", source: "sklearn:breast_cancer", event: "Loaded 569×30" },
  ],
  diffs: [
    { step: "logreg (raw)", before: 0.951, after: 0.951, delta: 0.0 },
    { step: "+ StandardScaler", before: 0.951, after: 0.979, delta: 0.028 },
    { step: "tune C=1.0", before: 0.979, after: 0.986, delta: 0.007 },
  ],
  findings: [
    { stat: "+53.8% / −45%", label: "compute saved on familiar regimes / lost on novel — the oracle helps only where calibrated" },
    { stat: "48.3% → 92.6%", label: "post-training: Qwen3-0.6B prediction accuracy (+44 pts)" },
    { stat: "r = 0.45", label: "calibration → compute saved, causal · 95% CI [0.28, 0.63]" },
    { stat: "28.6%", label: "live world-model interval coverage — overconfident, so the verifier gates every claim" },
  ],
}

/**
 * getRun — the single seam between UI and backend.
 * Serves the statically exported run.json (real backend artifacts projected to
 * the Run type by the backend exporter). Falls back to the embedded RUN fixture
 * if the file is missing, so the UI still works offline.
 */
export async function getRun(): Promise<Run> {
  // Server (RSC): read the statically-exported file straight from disk so SSR
  // shows the real run (a relative fetch has no origin on the server).
  if (typeof window === "undefined") {
    try {
      const { readFile } = await import("node:fs/promises")
      const { join } = await import("node:path")
      const raw = await readFile(join(process.cwd(), "public", "run.json"), "utf-8")
      return JSON.parse(raw) as Run
    } catch {
      return RUN
    }
  }
  // Client: fetch the static file.
  try {
    const res = await fetch("/run.json", { cache: "no-store" })
    if (!res.ok) throw new Error(`run.json ${res.status}`)
    return (await res.json()) as Run
  } catch {
    return RUN
  }
}

export const NAV = ["QUERY", "PIPELINE", "PAPERS", "TRACES", "STATES", "VERDICT"] as const

export type NavKey = (typeof NAV)[number]

// Each nav view maps to a stage of the Track 3 research loop.
export const VIEW_META: Record<NavKey, { title: string; stage: string; blurb: string }> = {
  QUERY: {
    title: "Query",
    stage: "Command",
    blurb: "Ask the world model. It forecasts experiment outcomes before compute and runs the loop.",
  },
  PIPELINE: {
    title: "Pipeline",
    stage: "Autonomous loop",
    blurb: "Literature → Predict → Run → Verify → Report. The agent drives every step and streams its log.",
  },
  PAPERS: {
    title: "Papers",
    stage: "Literature review",
    blurb: "Sources crawled from arXiv, fetched, and parsed into structured claims with provenance.",
  },
  TRACES: {
    title: "Traces",
    stage: "Provenance",
    blurb: "Every extracted claim and experiment result is traced back to a verifiable source.",
  },
  STATES: {
    title: "State Diffs",
    stage: "Experiment analysis",
    blurb: "How each pipeline transform moved measured accuracy — the real numbers behind the verdict.",
  },
  VERDICT: {
    title: "Verdict",
    stage: "Report",
    blurb: "The deterministic verifier gates the final claim: no result survives unless it beats seed noise.",
  },
}

// ---------------------------------------------------------------------------
// Two registers over the SAME data. "oracle" = grim/prophetic flavour.
// "lab" = sober statistical language a real ML lab would accept.
export type Lens = "oracle" | "lab"

export const LENS: Record<
  Lens,
  {
    subtitle: string
    intro: string
    probLabel: string
    accLabel: string
    runIdle: string
    runBusy: string
    tags: { top: string; anomaly: string; low: string }
    effectWord: string
    noiseWord: string
  }
> = {
  oracle: {
    subtitle: "World Model · Predicts Next States",
    intro:
      "The world model forecasts experiment outcomes before compute. The verifier gates every claim after the real run.",
    probLabel: "Prob",
    accLabel: "acc",
    runIdle: "RUN",
    runBusy: "DIVINING",
    tags: { top: "TOP OUTCOME", anomaly: "ANOMALY", low: "LOW CONFIDENCE" },
    effectWord: "effect",
    noiseWord: "seed noise",
  },
  lab: {
    subtitle: "World Model · Predicts experiment outcomes before compute",
    intro:
      "Policy scores (softmax, T=0.20) rank candidate pipelines before compute. CV accuracy reported as repeated 5-fold mean with 95% CI. Every claim is gated by an effect-vs-noise verifier.",
    probLabel: "policy p",
    accLabel: "CV acc 95% CI",
    runIdle: "RUN",
    runBusy: "RUNNING",
    tags: { top: "BEST CANDIDATE", anomaly: "OFF-POLICY", low: "LOW CONFIDENCE" },
    effectWord: "Δacc",
    noiseWord: "seed std",
  },
}
