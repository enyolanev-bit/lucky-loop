"use client"

import type React from "react"
import { useCallback, useEffect, useRef, useState } from "react"
import { Database, ShieldAlert, Crown, Zap, Loader2, Mic, MicOff } from "lucide-react"
import { LENS, type Prediction } from "@/lib/oracle-data"
import { useOracle } from "./oracle-provider"
import { cn } from "@/lib/utils"

// Precomputed (deterministic, fixed-precision) tick marks for the hero orrery —
// kept at module scope so server and client render byte-identical SVG (no hydration drift).
const ORRERY_TICKS = Array.from({ length: 48 }, (_, i) => {
  const a = ((i * 7.5) * Math.PI) / 180
  return {
    x1: (100 + Math.cos(a) * 97).toFixed(2),
    y1: (100 + Math.sin(a) * 97).toFixed(2),
    x2: (100 + Math.cos(a) * 90).toFixed(2),
    y2: (100 + Math.sin(a) * 90).toFixed(2),
  }
})

/** Voice-first input — Web Speech API (SpeechRecognition). Chrome/Edge. */
function MicButton({ onText }: { onText: (t: string) => void }) {
  const [listening, setListening] = useState(false)
  const [supported, setSupported] = useState(true)
  const recRef = useRef<any>(null)

  useEffect(() => {
    if (typeof window === "undefined") return
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SR) {
      setSupported(false)
      return
    }
    const rec = new SR()
    rec.lang = "en-US"
    rec.interimResults = true
    rec.continuous = false
    rec.onresult = (e: any) => {
      const transcript = Array.from(e.results)
        .map((r: any) => r[0].transcript)
        .join("")
      onText(transcript)
    }
    rec.onend = () => setListening(false)
    rec.onerror = () => setListening(false)
    recRef.current = rec
    return () => {
      try {
        rec.stop()
      } catch {
        /* noop */
      }
    }
  }, [onText])

  const toggle = useCallback(() => {
    const rec = recRef.current
    if (!rec) return
    if (listening) {
      rec.stop()
      setListening(false)
    } else {
      try {
        rec.start()
        setListening(true)
      } catch {
        /* already started */
      }
    }
  }, [listening])

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={!supported}
      aria-pressed={listening}
      aria-label={listening ? "Stop listening" : "Speak your query"}
      title={supported ? "Speak your query (Web Speech API)" : "Voice input not supported in this browser"}
      className={cn(
        "flex h-11 w-11 shrink-0 items-center justify-center rounded-md border transition-colors disabled:opacity-40",
        listening
          ? "animate-pulse-blood border-primary/70 bg-primary/25 text-primary shadow-[0_0_16px_oklch(0.55_0.2_25_/_45%)]"
          : "border-panel-line bg-[oklch(0.18_0.014_256_/_70%)] text-muted-foreground hover:text-foreground",
      )}
    >
      {listening ? <Mic className="h-5 w-5" aria-hidden /> : <MicOff className="h-5 w-5" aria-hidden />}
    </button>
  )
}

function ProbBar({ value }: { value: number }) {
  const filled = Math.round(value * 20)
  return (
    <div className="flex h-2.5 gap-px" aria-hidden>
      {Array.from({ length: 20 }).map((_, i) => (
        <span key={i} className={cn("w-1 rounded-[1px]", i < filled ? "bg-primary" : "bg-[oklch(0.3_0.014_256)]")} />
      ))}
    </div>
  )
}

function PredictionCard({ p }: { p: Prediction }) {
  const { lens } = useOracle()
  const copy = LENS[lens]
  const tone = p.tag?.tone
  const isAnomaly = tone === "anomaly"
  const isTop = tone === "top"
  const tagLabel = isTop ? copy.tags.top : isAnomaly ? copy.tags.anomaly : copy.tags.low
  return (
    <div
      className={cn(
        "group relative flex items-center gap-3 rounded-lg border bg-[oklch(0.19_0.013_256_/_85%)] p-3 transition-colors hover:border-primary/50",
        isTop ? "border-gold/60 shadow-[inset_0_0_24px_oklch(0.7_0.12_85_/_12%)]" : "border-panel-line",
      )}
    >
      <div className="grid h-7 w-7 shrink-0 place-items-center rounded-full border border-gold/60 font-mono text-xs font-bold text-gold">
        {p.rank}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-2">
          <div className="min-w-0">
            <p className="font-mono text-sm font-bold text-foreground">{p.config}</p>
            <p className="font-mono text-[10px] text-muted-foreground">{p.id}</p>
          </div>
          <div className="text-right">
            <p className="label-track text-[8px] text-muted-foreground">{copy.probLabel}</p>
            <p className="heading-track text-lg font-black leading-none text-foreground">{p.probability.toFixed(2)}</p>
          </div>
        </div>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="rounded-sm border border-steel/50 bg-steel/10 px-1.5 py-0.5 font-mono text-[10px] text-steel">
              {copy.accLabel} {p.accLow.toFixed(2)}–{p.accHigh.toFixed(2)}
            </span>
            {p.tag && (
              <span
                className={cn(
                  "label-track flex items-center gap-1 rounded-sm border px-1.5 py-0.5 text-[8px] font-bold",
                  isAnomaly && "border-primary/60 bg-primary/15 text-primary",
                  isTop && "border-gold/70 bg-gold/15 text-gold",
                  !isAnomaly && !isTop && "border-warn/60 bg-warn/10 text-warn",
                )}
              >
                {isAnomaly && <ShieldAlert className="h-2.5 w-2.5" aria-hidden />}
                {isTop && <Crown className="h-2.5 w-2.5" aria-hidden />}
                {tagLabel}
              </span>
            )}
          </div>
          <ProbBar value={p.probability} />
        </div>
      </div>
    </div>
  )
}

export function PredictBoard() {
  const { run, query, setQuery, start, running, lens } = useOracle()
  const { currentState, predictions, verdict } = run
  const copy = LENS[lens]
  const isLab = lens === "lab"

  return (
    <section className="flex flex-col gap-4">
      {/* immersive stage — Curze at the orrery */}
      <div className="relative min-h-[470px] overflow-hidden rounded-xl border border-panel-line lg:min-h-[580px]">
        <div
          className="absolute inset-0 bg-cover bg-[center_top]"
          style={{ backgroundImage: "url(/images/curze-hero.jpeg)" }}
          aria-hidden
        />
        {/* warm glow at the wheel hub */}
        <div className="pointer-events-none absolute left-1/2 top-[55%] h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,oklch(0.74_0.14_80_/_0.3),transparent_70%)] blur-2xl" />
        {/* spinning astrolabe on the baked-in wheel */}
        <div className="pointer-events-none absolute left-1/2 top-[55%] aspect-square w-[82%] max-w-[600px] -translate-x-1/2 -translate-y-1/2 opacity-75 mix-blend-screen">
          <svg viewBox="0 0 200 200" className="animate-orrery-cw absolute inset-0 h-full w-full">
            <g fill="none" stroke="oklch(0.8 0.13 82)" strokeOpacity="0.6">
              <circle cx="100" cy="100" r="97" strokeWidth="0.5" />
              <circle cx="100" cy="100" r="82" strokeWidth="0.4" />
              {ORRERY_TICKS.map((t, i) => (
                <line key={i} x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2} strokeWidth="0.5" />
              ))}
            </g>
            <circle cx="100" cy="3" r="2.6" fill="oklch(0.86 0.13 82)" />
          </svg>
          <svg viewBox="0 0 200 200" className="animate-orrery-ccw absolute inset-0 h-full w-full">
            <g fill="none" stroke="oklch(0.8 0.13 82)" strokeOpacity="0.55">
              <circle cx="100" cy="100" r="64" strokeWidth="0.5" />
              <circle cx="100" cy="100" r="42" strokeWidth="0.4" />
              <circle cx="100" cy="100" r="22" strokeWidth="0.4" />
              <line x1="3" y1="100" x2="197" y2="100" strokeWidth="0.35" strokeOpacity="0.35" />
              <line x1="100" y1="36" x2="100" y2="164" strokeWidth="0.35" strokeOpacity="0.35" />
            </g>
            <circle cx="100" cy="36" r="2.2" fill="oklch(0.88 0.12 82)" />
            <circle cx="158" cy="100" r="1.8" fill="oklch(0.88 0.12 82)" />
            <circle cx="100" cy="158" r="1.6" fill="oklch(0.84 0.13 82)" />
          </svg>
        </div>
        {/* vignettes for legibility */}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background via-background/35 to-transparent" />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(120%_85%_at_50%_-5%,transparent_45%,oklch(0.1_0.01_256_/_0.5))]" />

        {/* title */}
        <div className="pointer-events-none absolute left-4 top-4 z-10">
          <p className="heading-track text-lg font-black tracking-wide text-foreground drop-shadow-[0_2px_10px_oklch(0_0_0/85%)] md:text-xl">
            THE ORACLE SEES
          </p>
          <p className="label-track text-[10px] font-bold text-primary">PREDICT BEFORE COMPUTE · VERIFY BEFORE CLAIM</p>
        </div>

        {/* current state — left overlay (vertically centred, mirrors predictions) */}
        <div className="absolute left-4 top-1/2 z-10 w-[min(282px,calc(100%-2rem))] -translate-y-1/2 rounded-lg border border-panel-line bg-[oklch(0.11_0.013_256_/_0.8)] p-3 backdrop-blur-sm">
          <p className="label-track mb-2 text-[10px] font-bold text-foreground">Current State</p>
          <div className="flex gap-3">
            <div className="grid h-12 w-12 shrink-0 place-items-center rounded-md border border-panel-line bg-[oklch(0.16_0.014_256)]">
              <Database className="h-6 w-6 text-steel" aria-hidden />
            </div>
            <div className="min-w-0 space-y-1">
              <div>
                <p className="label-track text-[8px] text-muted-foreground">State ID</p>
                <p className="font-mono text-sm font-bold text-foreground">{currentState.id}</p>
              </div>
              <div>
                <p className="label-track text-[8px] text-muted-foreground">Dataset</p>
                <p className="font-mono text-[13px] text-foreground">{currentState.dataset}</p>
              </div>
            </div>
          </div>
          <div className="mt-2 border-t border-panel-line pt-2">
            <p className="label-track text-[8px] text-muted-foreground">Sources</p>
            <p className="text-[11px] leading-relaxed text-foreground">{currentState.context}</p>
          </div>
        </div>

        {/* predicted next states — right overlay (scrolls if many candidates) */}
        <div className="absolute right-4 top-1/2 z-10 flex max-h-[calc(100%-2rem)] w-[min(322px,calc(100%-2rem))] -translate-y-1/2 flex-col gap-2 overflow-y-auto pr-1">
          <p className="label-track text-[10px] font-bold text-foreground drop-shadow-[0_1px_6px_oklch(0_0_0/85%)]">
            Predicted Next States · {predictions.length}
          </p>
          {predictions.map((p) => (
            <PredictionCard key={p.id} p={p} />
          ))}
        </div>
      </div>

      {/* verdict */}
      <div
        className={cn(
          "relative overflow-hidden rounded-lg border",
          isLab
            ? "border-warn/40 bg-[oklch(0.18_0.02_70_/_50%)]"
            : "border-primary/50 bg-[oklch(0.2_0.04_25_/_55%)] shadow-[inset_0_0_40px_oklch(0.4_0.18_25_/_25%)]",
        )}
      >
        <div className="flex flex-col items-center gap-1 px-6 py-4 text-center">
          <div className="flex items-center gap-3">
            <span
              className={cn(
                "label-track rounded-sm border px-2 py-0.5 text-[10px] font-bold",
                isLab ? "border-warn/60 bg-warn/15 text-warn" : "border-primary/70 bg-primary/20 text-primary",
              )}
            >
              VERDICT
            </span>
            <h3
              className={cn(
                "heading-track font-black tracking-wide",
                isLab
                  ? "text-lg text-warn md:text-xl"
                  : "text-2xl text-primary drop-shadow-[0_0_14px_oklch(0.55_0.2_25_/_60%)] md:text-[26px]",
              )}
            >
              {isLab ? verdict.titleLab : verdict.title}
            </h3>
          </div>
          <p className="font-mono text-[13px] text-foreground/90">
            {copy.effectWord} <span className="text-primary">{verdict.effect.toFixed(3)}</span>{" "}
            {verdict.state === "CONFIRMED" ? ">" : "<"} {copy.noiseWord}{" "}
            <span className="text-gold">{verdict.noise.toFixed(3)}</span>
          </p>
          <p className={cn("text-sm text-foreground/75", isLab ? "max-w-2xl" : "italic")}>
            {isLab ? verdict.reasonLab : verdict.reason}
          </p>
        </div>
      </div>

      {/* ask the oracle */}
      <form
        onSubmit={(e: React.FormEvent) => {
          e.preventDefault()
          start()
        }}
        className="flex items-center gap-2 rounded-lg border border-panel-line bg-[oklch(0.18_0.013_256_/_80%)] p-2"
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={
            isLab
              ? "Query the world model…  (e.g. best model for breast_cancer?)"
              : "Ask the Oracle…  (e.g. best model for breast_cancer?)"
          }
          aria-label={isLab ? "Query the world model" : "Ask the Oracle"}
          className="flex-1 bg-transparent px-3 py-2 text-base text-foreground placeholder:text-muted-foreground focus:outline-none"
        />
        <MicButton onText={setQuery} />
        <button
          type="submit"
          disabled={running}
          className="flex h-11 items-center gap-2 rounded-md border border-primary/60 bg-primary/20 px-4 font-bold text-primary transition-colors hover:bg-primary/30 disabled:opacity-60"
        >
          {running ? <Loader2 className="h-5 w-5 animate-spin" aria-hidden /> : <Zap className="h-5 w-5" aria-hidden />}
          <span className="label-track text-xs">{running ? copy.runBusy : copy.runIdle}</span>
        </button>
      </form>
    </section>
  )
}
