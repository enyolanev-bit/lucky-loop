"use client"

import { useEffect, useRef } from "react"
import {
  Globe2,
  FileDown,
  ScrollText,
  Brain,
  FlaskConical,
  ShieldCheck,
  FileText,
  Skull,
} from "lucide-react"
import type { StepStatus } from "@/lib/oracle-data"
import { useOracle } from "./oracle-provider"
import { cn } from "@/lib/utils"

const STEP_ICONS = [Globe2, FileDown, ScrollText, Brain, FlaskConical, ShieldCheck, FileText]

function StatusBadge({ status, active }: { status: StepStatus; active: boolean }) {
  const styles: Record<StepStatus, string> = {
    RUNNING: "border-steel/60 bg-steel/15 text-steel",
    DONE: "border-ok/60 bg-ok/15 text-ok",
    QUEUED: "border-warn/60 bg-warn/15 text-warn",
  }
  return (
    <span
      className={cn(
        "label-track rounded-sm border px-2 py-0.5 text-[9px] font-bold",
        styles[status],
        active && status === "RUNNING" && "animate-pulse-blood",
      )}
    >
      {status}
    </span>
  )
}

const TONE: Record<string, string> = {
  info: "text-steel",
  ok: "text-ok",
  miss: "text-warn",
  alert: "text-primary",
}

export function GoonRun() {
  const { run, statuses, activeStep, log, clearLog } = useOracle()
  const logRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [log])

  return (
    <section className="flex h-full flex-col gap-3 rounded-lg border border-panel-line bg-[oklch(0.17_0.013_256_/_80%)] p-4">
      <div className="flex items-center gap-2 border-b border-panel-line pb-3">
        <Skull className="h-6 w-6 text-foreground" aria-hidden />
        <div>
          <h2 className="heading-track text-lg font-black text-foreground">AUTO-RESEARCH PIPELINE</h2>
          <p className="label-track text-[9px] text-muted-foreground">Literature → Predict → Run → Verify → Report</p>
        </div>
      </div>

      <ol className="flex flex-col gap-1.5">
        {run.pipeline.map((step, i) => {
          const Icon = STEP_ICONS[i]
          const status = statuses[i]
          const active = activeStep === i
          return (
            <li
              key={step.key}
              className={cn(
                "flex items-center gap-3 rounded-md border px-3 py-2 transition-colors",
                active
                  ? "border-primary/60 bg-primary/10"
                  : "border-panel-line bg-[oklch(0.19_0.013_256_/_70%)]",
              )}
            >
              <span className="heading-track w-3 text-sm font-bold text-muted-foreground">{i + 1}</span>
              <Icon className={cn("h-4 w-4 shrink-0", active ? "text-primary" : "text-steel")} aria-hidden />
              <div className="min-w-0 flex-1">
                <p className="label-track text-[11px] font-bold text-foreground">{step.title}</p>
                <p className="truncate text-[10px] text-muted-foreground">{step.detail}</p>
              </div>
              <StatusBadge status={status} active={active} />
            </li>
          )
        })}
      </ol>

      <div className="mt-1 flex items-center justify-between border-t border-panel-line pt-3">
        <h3 className="label-track text-[10px] font-bold text-foreground">Run Log (Live)</h3>
        <button
          type="button"
          onClick={clearLog}
          className="label-track text-[9px] text-muted-foreground hover:text-foreground"
        >
          Clear
        </button>
      </div>

      <div
        ref={logRef}
        className="h-44 flex-1 space-y-1 overflow-y-auto rounded-md border border-panel-line bg-[oklch(0.12_0.012_256)] p-3 font-mono text-[11px] leading-relaxed"
      >
        {log.length === 0 ? (
          <p className="text-muted-foreground/60">
            <span className="text-gold">∴</span> idle — press RUN to wake the oracle…
          </p>
        ) : (
          log.map((line, i) => (
            <p key={i} className={cn(line.tone === "alert" && "animate-pulse-blood")}>
              <span className="text-foreground/40">{line.time}</span>{" "}
              <span className={cn(TONE[line.tone ?? "info"])}>[{line.tag}]</span>{" "}
              <span className="text-foreground/85">{line.text}</span>
            </p>
          ))
        )}
      </div>
    </section>
  )
}
