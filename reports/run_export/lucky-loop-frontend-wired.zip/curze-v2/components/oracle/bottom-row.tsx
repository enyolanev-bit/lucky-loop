import { FileText, Filter, GitCompareArrows, Check, ArrowUp, ExternalLink } from "lucide-react"
import type { Diff, Paper, Trace } from "@/lib/oracle-data"

function PanelHead({ icon, title }: { icon: React.ReactNode; title: string }) {
  return (
    <div className="flex items-center justify-between border-b border-panel-line pb-2">
      <div className="flex items-center gap-2">
        <span className="text-primary">{icon}</span>
        <h2 className="heading-track text-base font-bold text-foreground">{title}</h2>
      </div>
    </div>
  )
}

function Panel({ children }: { children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-3 rounded-lg border border-panel-line bg-[oklch(0.17_0.013_256_/_80%)] p-4">
      {children}
    </section>
  )
}

export function PapersPanel({ papers }: { papers: Paper[] }) {
  return (
    <Panel>
      <PanelHead icon={<FileText className="h-4 w-4" aria-hidden />} title="PAPERS" />
      <ul className="flex flex-col gap-3">
        {papers.map((p) => (
          <li key={p.ref} className="flex items-center gap-3">
            <FileText className="h-5 w-5 shrink-0 text-muted-foreground" aria-hidden />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[13px] font-semibold text-foreground">{p.title}</p>
              <p className="truncate text-[11px] text-muted-foreground">{p.authors}</p>
            </div>
            <span className="hidden items-center gap-1 rounded-sm border border-steel/40 bg-steel/10 px-1.5 py-0.5 font-mono text-[10px] text-steel sm:flex">
              {p.ref}
            </span>
            <span className="flex items-center gap-1 rounded-sm border border-ok/40 bg-ok/10 px-1.5 py-0.5 text-[9px] text-ok">
              <Check className="h-2.5 w-2.5" aria-hidden /> CLEAN
            </span>
            <a
              href={p.url}
              target="_blank"
              rel="noreferrer"
              aria-label={`Open ${p.ref}`}
              className="grid h-7 w-7 shrink-0 place-items-center rounded-md border border-panel-line font-mono text-muted-foreground hover:text-foreground"
            >
              <ExternalLink className="h-3.5 w-3.5" aria-hidden />
            </a>
          </li>
        ))}
      </ul>
    </Panel>
  )
}

export function TracesPanel({ traces }: { traces: Trace[] }) {
  return (
    <Panel>
      <PanelHead icon={<Filter className="h-4 w-4" aria-hidden />} title="TRACES" />
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="label-track text-[8px] text-muted-foreground">
              <th className="py-1 font-semibold">Time</th>
              <th className="py-1 font-semibold">Source</th>
              <th className="py-1 font-semibold">Event</th>
              <th className="py-1 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody className="text-[11px]">
            {traces.map((t, i) => (
              <tr key={i} className="border-t border-panel-line/60">
                <td className="py-2 pr-2 font-mono text-muted-foreground">{t.time}</td>
                <td className="max-w-[130px] truncate py-2 pr-2 font-mono text-steel">{t.source}</td>
                <td className="py-2 pr-2 text-foreground">{t.event}</td>
                <td className="py-2">
                  <span className="flex items-center gap-1 text-ok">
                    <Check className="h-3 w-3" aria-hidden /> CLEAN
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Panel>
  )
}

export function DiffsPanel({ diffs }: { diffs: Diff[] }) {
  return (
    <Panel>
      <PanelHead icon={<GitCompareArrows className="h-4 w-4" aria-hidden />} title="STATE DIFFS" />
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="label-track text-[8px] text-muted-foreground">
              <th className="py-1 font-semibold">Step</th>
              <th className="py-1 text-right font-semibold">Before</th>
              <th className="py-1 text-right font-semibold">After</th>
              <th className="py-1 text-right font-semibold">Delta</th>
            </tr>
          </thead>
          <tbody className="text-[11px]">
            {diffs.map((d, i) => {
              const up = d.delta > 0
              return (
                <tr key={i} className="border-t border-panel-line/60">
                  <td className="py-2 pr-2 font-mono text-foreground">{d.step}</td>
                  <td className="py-2 pr-2 text-right font-mono text-muted-foreground">{d.before.toFixed(3)}</td>
                  <td className="py-2 pr-2 text-right font-mono text-foreground">{d.after.toFixed(3)}</td>
                  <td className="py-2 text-right">
                    <span
                      className={
                        up ? "flex items-center justify-end gap-0.5 font-mono text-ok" : "font-mono text-muted-foreground"
                      }
                    >
                      {up && <ArrowUp className="h-2.5 w-2.5" aria-hidden />}
                      {up ? `+${d.delta.toFixed(3)}` : d.delta.toFixed(3)}
                    </span>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </Panel>
  )
}

export function BottomRow({ papers, traces, diffs }: { papers: Paper[]; traces: Trace[]; diffs: Diff[] }) {
  return (
    <div className="grid gap-4 xl:grid-cols-3">
      <PapersPanel papers={papers} />
      <TracesPanel traces={traces} />
      <DiffsPanel diffs={diffs} />
    </div>
  )
}
