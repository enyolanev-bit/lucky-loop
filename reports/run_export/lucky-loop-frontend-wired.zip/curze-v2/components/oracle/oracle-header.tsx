"use client"

import { Activity, Volume2, VolumeX, Skull, FlaskConical } from "lucide-react"
import { LENS, ORACLE } from "@/lib/oracle-data"
import { useOracle } from "./oracle-provider"
import { cn } from "@/lib/utils"

function LensToggle() {
  const { lens, setLens } = useOracle()
  const opts = [
    { key: "oracle" as const, label: "ORACLE", Icon: Skull },
    { key: "lab" as const, label: "LAB", Icon: FlaskConical },
  ]
  return (
    <div
      role="radiogroup"
      aria-label="Display register"
      className="flex items-center gap-1 rounded-md border border-panel-line bg-[oklch(0.18_0.014_256_/_70%)] p-1"
    >
      {opts.map(({ key, label, Icon }) => {
        const active = lens === key
        return (
          <button
            key={key}
            type="button"
            role="radio"
            aria-checked={active}
            onClick={() => setLens(key)}
            className={cn(
              "flex items-center gap-1.5 rounded px-2.5 py-1.5 transition-colors",
              active
                ? "bg-primary/20 text-primary shadow-[0_0_14px_oklch(0.55_0.2_25_/_35%)]"
                : "text-muted-foreground hover:text-foreground",
            )}
          >
            <Icon className="h-3.5 w-3.5" aria-hidden />
            <span className="label-track text-[10px] font-bold">{label}</span>
          </button>
        )
      })}
    </div>
  )
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="flex flex-col justify-center border-l border-panel-line px-4 py-2">
      <span className="label-track text-[9px] text-muted-foreground">{label}</span>
      <span className={cn("font-mono text-[13px] font-bold", accent ? "text-primary" : "text-foreground")}>
        {value}
      </span>
    </div>
  )
}

export function OracleHeader() {
  const { voiceOn, toggleVoice, lens } = useOracle()
  const copy = LENS[lens]

  return (
    <header className="relative overflow-hidden rounded-lg border border-panel-line">
      <div
        className="absolute inset-0 bg-cover bg-[center_28%]"
        style={{ backgroundImage: "url(/images/curze-hero.jpeg)" }}
        aria-hidden
      />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/75 to-background/35" aria-hidden />
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" aria-hidden />

      <div className="relative flex flex-wrap items-center justify-between gap-4 p-5">
        <div className="flex flex-col justify-center">
          <h1 className="heading-track text-4xl font-black tracking-[0.06em] text-foreground drop-shadow-[0_2px_10px_oklch(0_0_0)] md:text-5xl">
            CURZE ORACLE
          </h1>
          <p className="label-track mt-1 text-[11px] font-semibold text-primary">{copy.subtitle}</p>
        </div>

        <div className="flex items-stretch">
          <div className="hidden items-stretch md:flex">
            <Stat label="Model" value={ORACLE.model} accent />
            <Stat label="Mode" value={ORACLE.mode} />
            <div className="flex flex-col justify-center border-l border-panel-line px-4 py-2">
              <span className="label-track text-[9px] text-muted-foreground">Status</span>
              <span className="flex items-center gap-1.5 font-mono text-[13px] font-bold text-ok">
                {ORACLE.status}
                <Activity className="h-3.5 w-3.5 animate-pulse-blood" aria-hidden />
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 pl-3">
            <LensToggle />
            <button
              type="button"
              onClick={toggleVoice}
              aria-pressed={voiceOn}
              aria-label={voiceOn ? "Disable oracle voice" : "Enable oracle voice"}
              title="Oracle voice (Web Speech API)"
              className={cn(
                "flex items-center gap-2 rounded-md border px-3 py-2 transition-colors",
                voiceOn
                  ? "border-primary/70 bg-primary/20 text-primary shadow-[0_0_16px_oklch(0.55_0.2_25_/_40%)]"
                  : "border-panel-line bg-[oklch(0.18_0.014_256_/_70%)] text-muted-foreground hover:text-foreground",
              )}
            >
              {voiceOn ? <Volume2 className="h-4 w-4" aria-hidden /> : <VolumeX className="h-4 w-4" aria-hidden />}
              <span className="label-track text-[10px] font-bold">{voiceOn ? "VOICE ON" : "VOICE"}</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
