"use client"

import { VIEW_META } from "@/lib/oracle-data"
import { useOracle } from "./oracle-provider"
import { PredictBoard } from "./predict-board"
import { GoonRun } from "./goon-run"
import { Findings } from "./findings"
import { PapersPanel, TracesPanel, DiffsPanel } from "./bottom-row"
import { VerdictView } from "./verdict-view"

function ViewHeader({ viewKey }: { viewKey: keyof typeof VIEW_META }) {
  const meta = VIEW_META[viewKey]
  return (
    <div className="flex flex-wrap items-end justify-between gap-2 border-b border-panel-line pb-3">
      <div>
        <h2 className="heading-track text-2xl font-black tracking-wide text-foreground">{meta.title}</h2>
        <p className="mt-1 max-w-2xl text-[11px] leading-relaxed text-muted-foreground">{meta.blurb}</p>
      </div>
      <span className="label-track shrink-0 rounded-sm border border-gold/40 bg-gold/10 px-2 py-1 text-[9px] font-bold text-gold">
        {meta.stage}
      </span>
    </div>
  )
}

export function MainView() {
  const { run, view } = useOracle()

  if (view === "QUERY") {
    return (
      <div className="space-y-4">
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_400px]">
          <PredictBoard />
          <GoonRun />
        </div>
        <Findings findings={run.findings} />
      </div>
    )
  }

  if (view === "PIPELINE") {
    return (
      <div className="space-y-4">
        <ViewHeader viewKey="PIPELINE" />
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_440px]">
          <Findings findings={run.findings} />
          <GoonRun />
        </div>
      </div>
    )
  }

  if (view === "PAPERS") {
    return (
      <div className="space-y-4">
        <ViewHeader viewKey="PAPERS" />
        <PapersPanel papers={run.papers} />
      </div>
    )
  }

  if (view === "TRACES") {
    return (
      <div className="space-y-4">
        <ViewHeader viewKey="TRACES" />
        <TracesPanel traces={run.traces} />
      </div>
    )
  }

  if (view === "STATES") {
    return (
      <div className="space-y-4">
        <ViewHeader viewKey="STATES" />
        <DiffsPanel diffs={run.diffs} />
      </div>
    )
  }

  // VERDICT
  return (
    <div className="space-y-4">
      <ViewHeader viewKey="VERDICT" />
      <VerdictView />
    </div>
  )
}
