import { Skull, Code2 } from "lucide-react"
import { ORACLE } from "@/lib/oracle-data"

function Item({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="label-track text-[9px] text-muted-foreground">{label}:</span>
      <span className={`font-mono text-[11px] ${accent ? "text-primary" : "text-foreground"}`}>{value}</span>
    </span>
  )
}

export function StatusBar() {
  return (
    <footer className="flex flex-wrap items-center gap-x-6 gap-y-2 rounded-lg border border-panel-line bg-[oklch(0.14_0.012_256_/_80%)] px-5 py-3">
      <Item label="Model" value={ORACLE.model} accent />
      <Item label="Context" value={ORACLE.context} />
      <a
        href={`https://${ORACLE.repo}`}
        target="_blank"
        rel="noreferrer"
        className="flex items-center gap-1.5 font-mono text-[11px] text-steel hover:text-foreground"
      >
        <Code2 className="h-3.5 w-3.5" aria-hidden />
        {ORACLE.repo}
      </a>
      <span className="ml-auto flex items-center gap-2">
        <span className="heading-track text-sm font-bold italic tracking-wide text-primary">{ORACLE.motto}</span>
        <Skull className="h-4 w-4 text-primary" aria-hidden />
      </span>
    </footer>
  )
}
