import { Flame } from "lucide-react"
import type { Finding } from "@/lib/oracle-data"

export function Findings({ findings }: { findings: Finding[] }) {
  return (
    <section className="rounded-lg border border-panel-line bg-[oklch(0.17_0.013_256_/_80%)] p-4">
      <div className="mb-3 flex items-center gap-2 border-b border-panel-line pb-2">
        <Flame className="h-4 w-4 text-primary" aria-hidden />
        <h2 className="heading-track text-base font-bold text-foreground">FINDINGS</h2>
        <span className="label-track text-[9px] text-muted-foreground">measured results · lucky-loop</span>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {findings.map((f) => (
          <div
            key={f.stat}
            className="flex flex-col gap-1 rounded-md border border-panel-line bg-[oklch(0.19_0.013_256_/_70%)] p-3"
          >
            <p className="heading-track text-xl font-black text-gold">{f.stat}</p>
            <p className="text-[11px] leading-relaxed text-muted-foreground">{f.label}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
