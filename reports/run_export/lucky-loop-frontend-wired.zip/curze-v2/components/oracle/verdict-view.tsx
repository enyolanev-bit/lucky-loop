"use client"

import { ShieldX } from "lucide-react"
import { LENS } from "@/lib/oracle-data"
import { useOracle } from "./oracle-provider"
import { DiffsPanel } from "./bottom-row"
import { cn } from "@/lib/utils"

export function VerdictView() {
  const { run, lens } = useOracle()
  const { verdict } = run
  const copy = LENS[lens]
  const isLab = lens === "lab"

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div
        className={cn(
          "relative overflow-hidden rounded-lg border p-8",
          isLab
            ? "border-warn/40 bg-[oklch(0.18_0.02_70_/_50%)]"
            : "border-primary/50 bg-[oklch(0.2_0.04_25_/_55%)] shadow-[inset_0_0_60px_oklch(0.4_0.18_25_/_25%)]",
        )}
      >
        <div className="flex flex-col items-center gap-3 text-center">
          <ShieldX className={cn("h-10 w-10", isLab ? "text-warn" : "text-primary")} aria-hidden />
          <span
            className={cn(
              "label-track rounded-sm border px-2 py-0.5 text-[10px] font-bold",
              isLab ? "border-warn/60 bg-warn/15 text-warn" : "border-primary/70 bg-primary/20 text-primary",
            )}
          >
            VERDICT
          </span>
          <h3
            className={cn(
              "heading-track font-black tracking-wide",
              isLab
                ? "text-2xl text-warn"
                : "text-3xl text-primary drop-shadow-[0_0_18px_oklch(0.55_0.2_25_/_60%)] md:text-4xl",
            )}
          >
            {isLab ? verdict.titleLab : verdict.title}
          </h3>
          <p className="font-mono text-sm text-foreground/90">
            {copy.effectWord} <span className="text-primary">{verdict.effect.toFixed(3)}</span> {"<"} {copy.noiseWord}{" "}
            <span className="text-gold">{verdict.noise.toFixed(3)}</span>
          </p>
          <p className={cn("max-w-xl text-sm leading-relaxed text-foreground/75", !isLab && "italic")}>
            {isLab ? verdict.reasonLab : verdict.reason}
          </p>
        </div>
      </div>
      <DiffsPanel diffs={run.diffs} />
    </div>
  )
}
