"use client"

import {
  createContext,
  useCallback,
  useContext,
  useRef,
  useState,
} from "react"
import type { Lens, LogLine, NavKey, Run, StepStatus } from "@/lib/oracle-data"

type LiveLog = LogLine & { time: string }

type OracleContextValue = {
  run: Run
  running: boolean
  voiceOn: boolean
  lens: Lens
  setLens: (l: Lens) => void
  view: NavKey
  setView: (v: NavKey) => void
  /** index of the step currently executing, or -1 when idle */
  activeStep: number
  /** per-step status keyed by pipeline order */
  statuses: StepStatus[]
  log: LiveLog[]
  query: string
  setQuery: (v: string) => void
  toggleVoice: () => void
  start: () => void
  clearLog: () => void
}

const OracleContext = createContext<OracleContextValue | null>(null)

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

function stamp() {
  const d = new Date()
  const p = (n: number) => String(n).padStart(2, "0")
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

export function OracleProvider({
  run,
  children,
}: {
  run: Run
  children: React.ReactNode
}) {
  const [running, setRunning] = useState(false)
  const [voiceOn, setVoiceOn] = useState(false)
  const [lens, setLens] = useState<Lens>("oracle")
  const [view, setView] = useState<NavKey>("QUERY")
  const [activeStep, setActiveStep] = useState(-1)
  const [statuses, setStatuses] = useState<StepStatus[]>(
    run.pipeline.map(() => "QUEUED"),
  )
  const [log, setLog] = useState<LiveLog[]>([])
  const [query, setQuery] = useState("")
  const voiceRef = useRef(false)
  const runningRef = useRef(false)

  const speak = useCallback((text: string) => {
    if (!voiceRef.current) return
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return
    const u = new SpeechSynthesisUtterance(text)
    u.rate = 0.95
    u.pitch = 0.6
    u.volume = 1
    window.speechSynthesis.speak(u)
  }, [])

  const toggleVoice = useCallback(() => {
    setVoiceOn((on) => {
      const next = !on
      voiceRef.current = next
      if (!next && typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel()
      } else if (next) {
        // prime synthesis on the user gesture so later utterances fire
        speak("The oracle awakens.")
      }
      return next
    })
  }, [speak])

  const clearLog = useCallback(() => setLog([]), [])

  const start = useCallback(async () => {
    if (runningRef.current) return
    runningRef.current = true
    setRunning(true)
    setLog([])
    setStatuses(run.pipeline.map(() => "QUEUED"))

    for (let i = 0; i < run.pipeline.length; i++) {
      const step = run.pipeline[i]
      setActiveStep(i)
      setStatuses((s) => s.map((v, idx) => (idx === i ? "RUNNING" : v)))
      speak(step.speak)

      for (const line of step.log) {
        await sleep(620)
        setLog((l) => [...l, { ...line, time: stamp() }])
      }

      await sleep(420)
      setStatuses((s) => s.map((v, idx) => (idx === i ? "DONE" : v)))
    }

    setActiveStep(-1)
    setRunning(false)
    runningRef.current = false
  }, [run.pipeline, speak])

  return (
    <OracleContext.Provider
      value={{
        run,
        running,
        voiceOn,
        lens,
        setLens,
        view,
        setView,
        activeStep,
        statuses,
        log,
        query,
        setQuery,
        toggleVoice,
        start,
        clearLog,
      }}
    >
      {children}
    </OracleContext.Provider>
  )
}

export function useOracle() {
  const ctx = useContext(OracleContext)
  if (!ctx) throw new Error("useOracle must be used within OracleProvider")
  return ctx
}
