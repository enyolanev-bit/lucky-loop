"use client"

import { Skull, Scroll, Target, Compass, Workflow, ShieldCheck } from "lucide-react"
import type { NavKey } from "@/lib/oracle-data"
import { useOracle } from "./oracle-provider"
import { cn } from "@/lib/utils"

const ITEMS: { key: NavKey; Icon: typeof Skull }[] = [
  { key: "QUERY", Icon: Skull },
  { key: "PIPELINE", Icon: Workflow },
  { key: "PAPERS", Icon: Scroll },
  { key: "TRACES", Icon: Target },
  { key: "STATES", Icon: Compass },
  { key: "VERDICT", Icon: ShieldCheck },
]

export function Sidebar() {
  const { view, setView } = useOracle()
  const active = view

  return (
    <aside className="flex w-[88px] shrink-0 flex-col items-center gap-1 border-r border-panel-line bg-[oklch(0.14_0.012_256_/_70%)] py-4">
      <div className="mb-3 grid h-12 w-12 place-items-center rounded-md border border-panel-line bg-[oklch(0.18_0.014_256)]">
        <Skull className="h-6 w-6 text-muted-foreground" aria-hidden />
      </div>

      <nav className="flex flex-1 flex-col items-center gap-1" aria-label="Oracle sections">
        {ITEMS.map(({ key, Icon }) => {
          const isActive = active === key
          return (
            <button
              key={key}
              type="button"
              onClick={() => setView(key)}
              aria-current={isActive ? "page" : undefined}
              className={cn(
                "group relative flex w-full flex-col items-center gap-1 py-3 transition-colors",
                isActive ? "text-primary-foreground" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {isActive && (
                <span className="absolute inset-x-2 inset-y-1 -z-0 rounded-md border border-primary/60 bg-primary/15 shadow-[0_0_18px_oklch(0.55_0.2_25_/_45%)]" />
              )}
              <span className="absolute left-0 top-1/2 h-7 w-[3px] -translate-y-1/2 rounded-r bg-primary opacity-0 transition-opacity data-[on=true]:opacity-100" data-on={isActive} />
              <Icon
                className={cn("z-10 h-5 w-5", isActive && "text-primary drop-shadow-[0_0_6px_oklch(0.55_0.2_25)]")}
                aria-hidden
              />
              <span className="label-track z-10 text-[9px] font-semibold">{key}</span>
            </button>
          )
        })}
      </nav>

      <div className="mt-2 flex flex-col items-center gap-1 border-t border-panel-line px-2 pt-4 text-center">
        <ShieldCheck className="h-5 w-5 text-gold" aria-hidden />
        <p className="label-track text-[8px] font-bold leading-tight text-primary">
          VERIFY
          <br />
          BEFORE
          <br />
          CLAIM
        </p>
      </div>
    </aside>
  )
}
